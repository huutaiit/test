## Supported Platforms

- Cordova CLI (3.6.3 or newer)
- Android (`cordova-android` 4.0.0 or higher)
- iOS
- Windows Universal (not Windows Phone 8)