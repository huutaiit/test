# Cordova Our Code World Prevent screenshots for android

# The plugin is ready for deployment

Add it to your project using

```batch
cordova plugin add https://github.com/sdkcarlos/cordova-ourcodeworld-preventscreenshots.git
```

# [Visit the homepage for more information](https://sdkcarlos.github.io/sites/cordova/disable-screenshots.html)
